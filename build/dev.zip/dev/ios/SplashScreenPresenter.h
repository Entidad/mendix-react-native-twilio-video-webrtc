#import <Foundation/Foundation.h>
#import "SplashScreenPresenterProtocol.h"

@interface SplashScreenPresenter : NSObject<SplashScreenPresenterProtocol>
@end
